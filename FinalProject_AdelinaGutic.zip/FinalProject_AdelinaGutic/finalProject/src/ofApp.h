#pragma once

#include <iostream>
#include "ofMain.h"
#include "ofxGui.h"
#include "ofxMaxim.h"

#include "maxiMFCC.h"
#define HOST "localhost"
#define PORT 12345

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

		// Sound
		ofSoundStream soundStream;
		void audioIn(ofSoundBuffer& input) override; 
		void audioOut(ofSoundBuffer& output) override;
	
		float* lAudioIn; /* inputs */
		float* rAudioIn;
		int		sampleRate;

		//MAXIMILIAN STUFF
		double wave, sample, outputs[2], ifftVal;
		maxiMix mymix;
		maxiOsc osc;

		ofxMaxiFFTOctaveAnalyzer oct;
		int nAverages;
		float* ifftOutput;
		int ifftSize;

		float peakFreq = 0;
		float centroid = 0;
		float RMS = 0;

		ofxMaxiIFFT ifft;
		ofxMaxiFFT mfft;
		int fftSize;
		int bins, dataSize;

		maxiMFCC mfcc;
		double* mfccs;
		maxiSample samp;

		// GUI Brush Parameters
		ofParameter<float> size;
		ofParameter<int> red;
		ofParameter<int> green;
		ofParameter<int> blue;
		ofParameter<float> transparency; 
		ofxPanel gui;
		
		// GUI Brush Shapes
		ofxButton circle;
		ofxButton square;
		ofxButton triangle;
		ofxButton glowing;
		ofxButton star;
		ofxPanel gui2;

		// GUI Freeform Brush
		ofxButton curvedLine;
		ofxButton straightLine;
		ofxPanel gui3;

		// GUI Extra Tools
		ofxButton saveColor1;
		ofColor color1 = (0, 0, 0, 100); //Default black
		ofxButton saveColor2;
		ofColor color2 = (0, 0, 0, 100);
		ofxButton saveColor3;
		ofColor color3 = (0, 0, 0, 100);
		ofxButton saveColor4;
		ofColor color4 = (0, 0, 0, 100);
		ofxPanel gui4;

		// GUI Audio Toggle
		ofxButton audioInput;
		ofxPanel gui5;

		// Brush Bools
		bool circles = true;
		bool squares = false;
		bool triangles = false;
		bool glow = false;
		bool stars = false;

		bool curved = false;
		bool straight = false;

		bool audio = false;

		// Freeform Brush Vars
		vector <ofPolyline> polylines;
		vector <ofPolyline> polylines2;
		ofPolyline currentPolyline;
		ofPolyline straightPolyline;
		bool leftMouseButtonPressed = false;
		ofVec2f lastPoint;
		float minDistance = 10;
		
		// Background Image
		ofImage myImage;
		ofMesh mesh;
		string imageType;
};
