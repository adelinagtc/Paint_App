#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	ofSetBackgroundAuto(false); //Prevents background from auto clearing

	//Set background and basics
	ofBackground(255);
	ofEnableAntiAliasing();
	ofSetCircleResolution(50);

	// SOUND ----------------------------------------------------------------------------------------
	sampleRate = 48000;  //44100
	int initialBufferSize = 512;

	lAudioIn = new float[initialBufferSize]; //inputs
	rAudioIn = new float[initialBufferSize];

	memset(lAudioIn, 0, initialBufferSize * sizeof(float));
	memset(rAudioIn, 0, initialBufferSize * sizeof(float));
	
	fftSize = 1024;
	mfft.setup(fftSize, 512, 256);
	ifft.setup(fftSize, 512, 256);

	nAverages = 12;
	oct.setup(sampleRate, fftSize / 2, nAverages);
	mfccs = (double*)malloc(sizeof(double) * 13);
	mfcc.setup(512, 42, 13, 20, 20000, sampleRate); 

	ofxMaxiSettings::setup(sampleRate, 2, initialBufferSize);

	ofSoundStreamSettings settings;
	auto devices = soundStream.getMatchingDevices("default");
	if (!devices.empty()) {
		settings.setInDevice(devices[0]);
	}
	settings.setInListener(this);
	settings.setOutListener(this);
	settings.sampleRate = sampleRate;
	settings.numOutputChannels = 2;
	settings.numInputChannels = 2;
	settings.bufferSize = initialBufferSize;
	soundStream.setup(settings);
	// --------------------------------------------------------------------------------------------

	//Setup GUIs
	gui.setup("Brush Parameters");
	gui.add(size.set("size", 20., 10., 300.));
	gui.add(red.set("red", 0., 0., 255));
	gui.add(green.set("green", 0., 0., 255));
	gui.add(blue.set("blue", 0., 0., 255));
	gui.add(transparency.set("transparency", 100., 0., 100.));

	gui2.setup("Brush Shape", ofxPanelDefaultFilename, 225.0F, 10.0F);
	gui2.add(circle.setup("circle"));
	gui2.add(square.setup("square"));
	gui2.add(triangle.setup("triangle"));
	gui2.add(glowing.setup("glowing"));
	gui2.add(star.setup("star"));

	gui3.setup("Freeform Brushes", ofxPanelDefaultFilename, 440.0F, 10.0F);
	gui3.add(curvedLine.setup("curved line"));
	gui3.add(straightLine.setup("straight Line"));

	gui4.setup("Saved Color", ofxPanelDefaultFilename, 665.0F, 10.0F);
	gui4.add(saveColor1.setup("saveColor1"));
	gui4.add(saveColor2.setup("saveColor2"));
	gui4.add(saveColor3.setup("saveColor3"));
	gui4.add(saveColor4.setup("saveColor4"));

	gui5.setup("Audio Toggle", ofxPanelDefaultFilename, 440.0F, 85.0F);
	gui5.add(audioInput.setup("Input"));

	//Terminal Setup
	std::cout << "\n" << "Input an image name, or 'none'!" << std::endl;
	
	string imageName;
	std::cin >> imageName;
	imageType = imageName.substr(imageName.size() - 3, 3);
	//std::cout << imageType << std::endl;
	if (imageName != "none") {
		//std::cout << "Not 'none'!" << std::endl;
		try {
			myImage.load(imageName);

			mesh.setMode(OF_PRIMITIVE_POINTS);
			mesh.enableColors();

			float intensityThreshold = 75.0;
			int w = myImage.getWidth();
			int h = myImage.getHeight();
			for (int x = 0; x < w; ++x) {
				for (int y = 0; y < h; ++y) {
					ofColor c = myImage.getColor(x, y);
					float intensity = c.getLightness();
					if (intensity >= intensityThreshold) {
						ofVec3f pos(x, y, 0.0);
						mesh.addVertex(pos);
						mesh.addColor(c);
					}
				}
			}
		}
		catch (string message) {
			std::cout << "Not a valid file name. Resorting to white background!" << std::endl;;
		}
	}
	else {
		std::cout << "Inputted 'none'!" << std::endl;
	} 
	//myImage.load("elephant.png");
}

//--------------------------------------------------------------
void ofApp::update(){
	// Button save states
	if (circle) {
		circles = true;
		squares = false;
		triangles = false;
		glow = false;
		stars = false;
		curved = false;
		straight = false;
	}
	if (square) {
		circles = false;
		squares = true;
		triangles = false;
		glow = false;
		stars = false;
		curved = false;
		straight = false;
	}
	if (triangle) {
		circles = false;
		squares = false;
		triangles = true;
		glow = false;
		stars = false;
		curved = false;
		straight = false;
	}
	if (glowing) {
		circles = false;
		squares = false;
		triangles = false;
		glow = true;
		stars = false;
		curved = false;
		straight = false;
	}
	if (star) {
		circles = false;
		squares = false;
		triangles = false;
		glow = false;
		stars = true;
		curved = false;
		straight = false;
	}
	if (curvedLine) {
		circles = false;
		squares = false;
		triangles = false;
		glow = false;
		stars = false;
		curved = true;
		straight = false;
	}
	if (straightLine) {
		circles = false;
		squares = false;
		triangles = false;
		glow = false;
		stars = false;
		curved = false;
		straight = true;
	}
	
	// ofColor save states
	if (saveColor1) {
		red = color1.r;
		green = color1.g;
		blue = color1.b;
		transparency = color1.a;
	}
	if (saveColor2) {
		red = color2.r;
		green = color2.g;
		blue = color2.b;
		transparency = color2.a;
	}
	if (saveColor3) {
		red = color3.r;
		green = color3.g;
		blue = color3.b;
		transparency = color3.a;
	}
	if (saveColor4) {
		red = color4.r;
		green = color4.g;
		blue = color4.b;
		transparency = color4.a;
	}

	// Input Toggle
	if (audioInput) {
		if (audio) {
			audio = false;
		}
		else {
			audio = true;
		}
	}


	// CurvedLine
	if (leftMouseButtonPressed && curved) {
		ofPoint mousePos(ofGetMouseX(), ofGetMouseY());
		if (lastPoint.distance(mousePos) >= minDistance) {
			currentPolyline.curveTo(mousePos);
			lastPoint = mousePos;
		}
	}
}

//--------------------------------------------------------------
void ofApp::draw(){
	//Load background images if necessary
	if (imageType == "png") {
		myImage.draw(0, 150);
	}
	else if (imageType == "jpg") {
		mesh.draw();
	}
	
	//Load GUIs
	gui.draw();
	gui2.draw();
	gui3.draw();
	gui4.draw();
	gui5.draw();

	if (ofGetMousePressed(OF_MOUSE_BUTTON_LEFT) && ofGetMouseY() > 150) {  // If the right mouse button is pressed...
		
		if (circles) {
			ofSetColor(red, green, blue, transparency);
			ofDrawCircle(ofGetMouseX(), ofGetMouseY(), size/2);
		}
		if (squares) {
			ofSetColor(red, green, blue, transparency);
			ofSetRectMode(OF_RECTMODE_CENTER);
			ofDrawRectangle(ofGetMouseX(), ofGetMouseY(), size, size);  // Draw a 50 x 50 rect centered over the mouse
			ofSetRectMode(OF_RECTMODE_CORNER);
		}
		if (triangles) {
			ofSetColor(red, green, blue, transparency);
			ofDrawTriangle(ofGetMouseX() - (size / 2), ofGetMouseY(), ofGetMouseX(), ofGetMouseY() - size, ofGetMouseX() + (size / 2), ofGetMouseY());
		
		} 
		if (glow) {
			int maxRadius = 30;  // Increase for a wider brush
			int radiusStepSize = 5;  // Decrease for more circles (i.e. a more opaque brush)
			int alpha = 3;  // Increase for a more opaque brush
			int maxOffsetDistance = size;  // Increase for a larger spread of circles
			// draw smaller and smaller circles and layering (increasing) opaqueness
			for (int radius = maxRadius; radius > 0; radius -= radiusStepSize) {
				float angle = ofRandom(ofDegToRad(360.0));
				float distance = ofRandom(maxOffsetDistance);
				float xOffset = cos(angle) * distance;
				float yOffset = sin(angle) * distance;
				ofSetColor(red, green, blue, alpha);
				ofDrawCircle(ofGetMouseX() + xOffset, ofGetMouseY() + yOffset, radius);
			}
		}
		if (stars) {
			int numLines = 30;
			int minRadius = 25;
			int maxRadius = size;
			for (int i = 0; i < numLines; i++) {
				float angle = ofRandom(ofDegToRad(360.0));
				float distance = ofRandom(minRadius, maxRadius);
				float xOffset = cos(angle) * distance;
				float yOffset = sin(angle) * distance;
				float alpha = ofMap(distance, minRadius, maxRadius, 50, 0);  // Make shorter lines more opaque
				ofSetColor(red, green, blue, alpha);
				ofDrawLine(ofGetMouseX(), ofGetMouseY(), ofGetMouseX() + xOffset, ofGetMouseY() + yOffset);
			}
		}
		if (curved) {
			ofSetLineWidth(size / 20);
			ofSetColor(red, green, blue, transparency); 
			for (int i = 0; i < polylines.size(); i++) {
				ofPolyline polyline = polylines[i];
				polyline.draw();
			}
			ofSetColor(255, 100, 0);  // Orange color for active polyline
			currentPolyline.draw();
		}
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	// Clears background
	if (key == 'c' || key == 'C') {
		ofSetBackgroundAuto(true);
	}
	
	// Saves screenshot of current screen
	if (key == 's' || key == 'S') {
		glReadBuffer(GL_FRONT);  // Only needed on windows, when using ofSetAutoBackground(false)
		ofSaveScreen("savedScreenshot_" + ofGetTimestampString() + ".png");
	}

	// Change background color quickly
	if (key == 'b') {
		ofBackground(red, green, blue);
	}
	
	// Save current brush color in slots 1-4
	if (key == '1') {
		color1.r = red;
		color1.g = green;
		color1.b = blue;
		color1.a = transparency;
	}
	if (key == '2') {
		color2.r = red;
		color2.g = green;
		color2.b = blue;
		color2.a = transparency;
	}
	if (key == '3') {
		color3.r = red;
		color3.g = green;
		color3.b = blue;
		color3.a = transparency;
	}
	if (key == '4') {
		color4.r = red;
		color4.g = green;
		color4.b = blue;
		color4.a = transparency;
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
	if (key == 'c' || key == 'C') {
		ofSetBackgroundAuto(false);
	}
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
	if (button == OF_MOUSE_BUTTON_LEFT && curved) {
		leftMouseButtonPressed = true;
		currentPolyline.curveTo(x, y); 
		currentPolyline.curveTo(x, y);  // Necessary duplicate for first control point
		lastPoint.set(x, y);  // Set the x and y of a ofVec2f in a single line
	}
	if (button == OF_MOUSE_BUTTON_LEFT && straight) {
		straightPolyline.addVertex(x, y); 
		straightPolyline.addVertex(x, y);
	}

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
	if (button == OF_MOUSE_BUTTON_LEFT && curved) {
		leftMouseButtonPressed = false;
		currentPolyline.curveTo(x, y); // Necessary duplicate for last control point
		polylines.push_back(currentPolyline);
		currentPolyline.clear();  // Erase the vertices, allows us to start a new brush stroke
	}
	
	if (button == OF_MOUSE_BUTTON_LEFT && straight) {
		straightPolyline.addVertex(x, y);
		polylines2.push_back(straightPolyline);

		ofSetLineWidth(size / 20);
		ofSetColor(red, green, blue, transparency);
		for (int i = 0; i < polylines2.size(); i++) {
			ofPolyline polyline = polylines2[i];
			polyline.draw();
		} 
		straightPolyline.clear();
	} 
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

//--------------------------------------------------------------
void ofApp::audioOut(ofSoundBuffer& output) {
	std::size_t outChannels = output.getNumChannels();
	for (size_t i = 0; i < output.getNumFrames(); ++i) {

	}
}

//--------------------------------------------------------------
void ofApp::audioIn(ofSoundBuffer& input) {
	if (audio) {
		float sum = 0;
		for (size_t i = 0; i < input.getNumFrames(); i++) {
			lAudioIn[i] = input[i * 2];
			rAudioIn[i] = input[i * 2 + 1];

			sum += input[i * 2] * input[i * 2];

		}
		RMS = sqrt(sum / (input.getNumFrames() * 0.01)); //Is normally divided by 0.5, but used smaller number here to create more dramatic effect
		RMS = RMS * 100;
		size = RMS;
		//std::cout << RMS << std::endl;
	}
}


